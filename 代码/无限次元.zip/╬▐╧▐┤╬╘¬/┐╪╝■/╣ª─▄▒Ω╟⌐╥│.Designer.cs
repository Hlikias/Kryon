﻿//無限次元:https://space.bilibili.com/2139404925
//本代码来自:https://github.com/becomequantum/Kryon
namespace 控件 {
    partial class 功能标签页 {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(功能标签页));
            this.切换工具栏 = new System.Windows.Forms.ToolStrip();
            this.图像处理按钮 = new System.Windows.Forms.ToolStripButton();
            this.神经网络按钮 = new System.Windows.Forms.ToolStripButton();
            this.Wb选值 = new System.Windows.Forms.ComboBox();
            this.点运算参数 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.W值 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.Bias值 = new System.Windows.Forms.ToolStripTextBox();
            this.随机刷按钮 = new System.Windows.Forms.Button();
            this.增益参数 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.R比例 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.G比例 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.B比例 = new System.Windows.Forms.ToolStripTextBox();
            this.RGB参数 = new System.Windows.Forms.ToolStrip();
            this.RGB标签 = new System.Windows.Forms.ToolStripLabel();
            this.R值 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.G值 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.B值 = new System.Windows.Forms.ToolStripTextBox();
            this.选色按钮 = new System.Windows.Forms.ToolStripButton();
            this.宽高参数 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.图宽 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.图高 = new System.Windows.Forms.ToolStripTextBox();
            this.位宽选择 = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.刷空图按钮 = new System.Windows.Forms.Button();
            this.神经网络panel = new System.Windows.Forms.Panel();
            this.Mnist查看按钮 = new System.Windows.Forms.Button();
            this.读Yolo标签按钮 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.点运算按钮 = new System.Windows.Forms.Button();
            this.转灰度按钮 = new System.Windows.Forms.Button();
            this.变透明按钮 = new System.Windows.Forms.Button();
            this.变RAW按钮 = new System.Windows.Forms.Button();
            this.RGB增益按钮 = new System.Windows.Forms.Button();
            this.二图相减按钮 = new System.Windows.Forms.Button();
            this.画直方图按钮 = new System.Windows.Forms.Button();
            this.直方图均衡化按钮 = new System.Windows.Forms.Button();
            this.Canny按钮 = new System.Windows.Forms.Button();
            this.Sobel按钮 = new System.Windows.Forms.Button();
            this.标背景按钮 = new System.Windows.Forms.Button();
            this.二值化按钮 = new System.Windows.Forms.Button();
            this.递归连通按钮 = new System.Windows.Forms.Button();
            this.是否显示过程 = new System.Windows.Forms.CheckBox();
            this.阈值胀蚀按钮 = new System.Windows.Forms.Button();
            this.取边缘按钮 = new System.Windows.Forms.Button();
            this.H使能 = new System.Windows.Forms.CheckBox();
            this.S使能 = new System.Windows.Forms.CheckBox();
            this.L使能 = new System.Windows.Forms.CheckBox();
            this.方波展开按钮 = new System.Windows.Forms.Button();
            this.三角波展开按钮 = new System.Windows.Forms.Button();
            this.金拱门展开按钮 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.算子直径 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.胀蚀阈值 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.下限标签 = new System.Windows.Forms.ToolStripLabel();
            this.H下 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.S下 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.L下 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.上限标签 = new System.Windows.Forms.ToolStripLabel();
            this.H上 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.S上 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.L上 = new System.Windows.Forms.ToolStripTextBox();
            this.切换工具栏.SuspendLayout();
            this.点运算参数.SuspendLayout();
            this.增益参数.SuspendLayout();
            this.RGB参数.SuspendLayout();
            this.宽高参数.SuspendLayout();
            this.神经网络panel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // 切换工具栏
            // 
            this.切换工具栏.Dock = System.Windows.Forms.DockStyle.None;
            this.切换工具栏.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.切换工具栏.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.图像处理按钮,
            this.神经网络按钮});
            this.切换工具栏.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.切换工具栏.Location = new System.Drawing.Point(0, 0);
            this.切换工具栏.Name = "切换工具栏";
            this.切换工具栏.Size = new System.Drawing.Size(70, 50);
            this.切换工具栏.TabIndex = 0;
            this.切换工具栏.Text = "toolStrip1";
            // 
            // 图像处理按钮
            // 
            this.图像处理按钮.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.图像处理按钮.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.图像处理按钮.Image = ((System.Drawing.Image)(resources.GetObject("图像处理按钮.Image")));
            this.图像处理按钮.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.图像处理按钮.Margin = new System.Windows.Forms.Padding(0);
            this.图像处理按钮.Name = "图像处理按钮";
            this.图像处理按钮.Size = new System.Drawing.Size(69, 23);
            this.图像处理按钮.Text = "图像处理";
            this.图像处理按钮.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.图像处理按钮.Click += new System.EventHandler(this.切换按钮_Click);
            // 
            // 神经网络按钮
            // 
            this.神经网络按钮.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.神经网络按钮.Image = ((System.Drawing.Image)(resources.GetObject("神经网络按钮.Image")));
            this.神经网络按钮.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.神经网络按钮.Name = "神经网络按钮";
            this.神经网络按钮.Size = new System.Drawing.Size(69, 24);
            this.神经网络按钮.Text = "神经网络";
            this.神经网络按钮.Click += new System.EventHandler(this.切换按钮_Click);
            // 
            // Wb选值
            // 
            this.Wb选值.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Wb选值.FormattingEnabled = true;
            this.Wb选值.Items.AddRange(new object[] {
            "-1 255",
            "1.1 0",
            "1.2 0",
            "1.5 0",
            "2.0 0",
            "0.9 0",
            "0.5 0",
            "1.04 10",
            "1.08 20",
            ""});
            this.Wb选值.Location = new System.Drawing.Point(483, 77);
            this.Wb选值.Name = "Wb选值";
            this.Wb选值.Size = new System.Drawing.Size(66, 25);
            this.Wb选值.TabIndex = 9;
            this.toolTip1.SetToolTip(this.Wb选值, "选择常用Wb值,-1,255为反色效果");
            this.Wb选值.SelectedValueChanged += new System.EventHandler(this.Wb选值改变);
            // 
            // 点运算参数
            // 
            this.点运算参数.AutoSize = false;
            this.点运算参数.Dock = System.Windows.Forms.DockStyle.None;
            this.点运算参数.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.点运算参数.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel5,
            this.W值,
            this.toolStripLabel6,
            this.Bias值});
            this.点运算参数.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.点运算参数.Location = new System.Drawing.Point(362, 78);
            this.点运算参数.Name = "点运算参数";
            this.点运算参数.Size = new System.Drawing.Size(118, 25);
            this.点运算参数.TabIndex = 8;
            this.点运算参数.Text = "toolStrip1";
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(23, 20);
            this.toolStripLabel5.Text = "W";
            this.toolStripLabel5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // W值
            // 
            this.W值.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.W值.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.W值.ForeColor = System.Drawing.SystemColors.ControlText;
            this.W值.MaxLength = 5;
            this.W值.Name = "W值";
            this.W值.Size = new System.Drawing.Size(42, 22);
            this.W值.Text = "-1.0";
            this.W值.ToolTipText = "W值,乘";
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(18, 20);
            this.toolStripLabel6.Text = "b";
            // 
            // Bias值
            // 
            this.Bias值.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Bias值.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Bias值.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Bias值.MaxLength = 3;
            this.Bias值.Name = "Bias值";
            this.Bias值.Size = new System.Drawing.Size(30, 22);
            this.Bias值.Text = "255";
            this.Bias值.ToolTipText = "b值,加";
            // 
            // 随机刷按钮
            // 
            this.随机刷按钮.AutoSize = true;
            this.随机刷按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.随机刷按钮.Location = new System.Drawing.Point(300, 2);
            this.随机刷按钮.Name = "随机刷按钮";
            this.随机刷按钮.Size = new System.Drawing.Size(59, 24);
            this.随机刷按钮.TabIndex = 7;
            this.随机刷按钮.Text = "随机刷";
            this.toolTip1.SetToolTip(this.随机刷按钮, "刷一张各点颜色值随机的位图");
            this.随机刷按钮.UseVisualStyleBackColor = true;
            this.随机刷按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 增益参数
            // 
            this.增益参数.AutoSize = false;
            this.增益参数.Dock = System.Windows.Forms.DockStyle.None;
            this.增益参数.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.增益参数.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.R比例,
            this.toolStripSeparator3,
            this.G比例,
            this.toolStripSeparator4,
            this.B比例});
            this.增益参数.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.增益参数.Location = new System.Drawing.Point(362, 53);
            this.增益参数.Name = "增益参数";
            this.增益参数.Size = new System.Drawing.Size(187, 25);
            this.增益参数.TabIndex = 6;
            this.增益参数.Text = "toolStrip1";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(37, 20);
            this.toolStripLabel4.Text = "比例";
            this.toolStripLabel4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripLabel4.ToolTipText = "用于转灰度和算RGB增益";
            // 
            // R比例
            // 
            this.R比例.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.R比例.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.R比例.ForeColor = System.Drawing.Color.Red;
            this.R比例.MaxLength = 5;
            this.R比例.Name = "R比例";
            this.R比例.Size = new System.Drawing.Size(42, 22);
            this.R比例.Text = "0.299";
            this.R比例.ToolTipText = "R比例或增益";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 23);
            // 
            // G比例
            // 
            this.G比例.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.G比例.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.G比例.ForeColor = System.Drawing.Color.Green;
            this.G比例.MaxLength = 5;
            this.G比例.Name = "G比例";
            this.G比例.Size = new System.Drawing.Size(42, 22);
            this.G比例.Text = "0.587";
            this.G比例.ToolTipText = "G比例或增益";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 23);
            // 
            // B比例
            // 
            this.B比例.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.B比例.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.B比例.ForeColor = System.Drawing.Color.Blue;
            this.B比例.MaxLength = 5;
            this.B比例.Name = "B比例";
            this.B比例.Size = new System.Drawing.Size(42, 22);
            this.B比例.Text = "0.114";
            this.B比例.ToolTipText = "B比例或增益";
            // 
            // RGB参数
            // 
            this.RGB参数.AutoSize = false;
            this.RGB参数.Dock = System.Windows.Forms.DockStyle.None;
            this.RGB参数.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RGB参数.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RGB标签,
            this.R值,
            this.toolStripSeparator1,
            this.G值,
            this.toolStripSeparator2,
            this.B值,
            this.选色按钮});
            this.RGB参数.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.RGB参数.Location = new System.Drawing.Point(362, 27);
            this.RGB参数.Name = "RGB参数";
            this.RGB参数.Size = new System.Drawing.Size(187, 25);
            this.RGB参数.TabIndex = 5;
            this.RGB参数.Text = "toolStrip1";
            // 
            // RGB标签
            // 
            this.RGB标签.Name = "RGB标签";
            this.RGB标签.Size = new System.Drawing.Size(37, 20);
            this.RGB标签.Text = "RGB";
            this.RGB标签.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // R值
            // 
            this.R值.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.R值.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.R值.ForeColor = System.Drawing.Color.Red;
            this.R值.MaxLength = 3;
            this.R值.Name = "R值";
            this.R值.Size = new System.Drawing.Size(30, 22);
            this.R值.Text = "0";
            this.R值.ToolTipText = "刷空图或变透明的R值";
            this.R值.TextChanged += new System.EventHandler(this.RGB_TextChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 23);
            // 
            // G值
            // 
            this.G值.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.G值.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.G值.ForeColor = System.Drawing.Color.Green;
            this.G值.MaxLength = 3;
            this.G值.Name = "G值";
            this.G值.Size = new System.Drawing.Size(30, 22);
            this.G值.Text = "0";
            this.G值.ToolTipText = "G值";
            this.G值.TextChanged += new System.EventHandler(this.RGB_TextChanged);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 23);
            // 
            // B值
            // 
            this.B值.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.B值.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.B值.ForeColor = System.Drawing.Color.Blue;
            this.B值.MaxLength = 3;
            this.B值.Name = "B值";
            this.B值.Size = new System.Drawing.Size(30, 22);
            this.B值.Text = "0";
            this.B值.ToolTipText = "B值";
            this.B值.TextChanged += new System.EventHandler(this.RGB_TextChanged);
            // 
            // 选色按钮
            // 
            this.选色按钮.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.选色按钮.Font = new System.Drawing.Font("新宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.选色按钮.ForeColor = System.Drawing.Color.Purple;
            this.选色按钮.Image = ((System.Drawing.Image)(resources.GetObject("选色按钮.Image")));
            this.选色按钮.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.选色按钮.Name = "选色按钮";
            this.选色按钮.Size = new System.Drawing.Size(39, 18);
            this.选色按钮.Text = "选色";
            this.选色按钮.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.选色按钮.ToolTipText = "打开调色板选一种颜色, 双击图像上某点也可取色";
            this.选色按钮.Click += new System.EventHandler(this.选色按钮_Click);
            // 
            // 宽高参数
            // 
            this.宽高参数.AutoSize = false;
            this.宽高参数.Dock = System.Windows.Forms.DockStyle.None;
            this.宽高参数.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.宽高参数.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.图宽,
            this.toolStripLabel2,
            this.图高,
            this.位宽选择});
            this.宽高参数.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.宽高参数.Location = new System.Drawing.Point(362, 2);
            this.宽高参数.Name = "宽高参数";
            this.宽高参数.Size = new System.Drawing.Size(187, 25);
            this.宽高参数.TabIndex = 4;
            this.宽高参数.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(23, 20);
            this.toolStripLabel1.Text = "宽";
            this.toolStripLabel1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // 图宽
            // 
            this.图宽.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.图宽.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.图宽.MaxLength = 4;
            this.图宽.Name = "图宽";
            this.图宽.Size = new System.Drawing.Size(40, 22);
            this.图宽.Text = "1920";
            this.图宽.ToolTipText = "刷空图的图宽";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(23, 20);
            this.toolStripLabel2.Text = "高";
            this.toolStripLabel2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // 图高
            // 
            this.图高.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.图高.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.图高.MaxLength = 4;
            this.图高.Name = "图高";
            this.图高.Size = new System.Drawing.Size(40, 22);
            this.图高.Text = "1080";
            this.图高.ToolTipText = "刷空图的图高";
            // 
            // 位宽选择
            // 
            this.位宽选择.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.位宽选择.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.位宽选择.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.位宽选择.Image = ((System.Drawing.Image)(resources.GetObject("位宽选择.Image")));
            this.位宽选择.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.位宽选择.Name = "位宽选择";
            this.位宽选择.Size = new System.Drawing.Size(50, 21);
            this.位宽选择.Text = "24位";
            this.位宽选择.ToolTipText = "选择位图是24还是32位";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(102, 22);
            this.toolStripMenuItem2.Text = "24位";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.位宽选择_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(102, 22);
            this.toolStripMenuItem3.Text = "32位";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.位宽选择_Click);
            // 
            // 刷空图按钮
            // 
            this.刷空图按钮.AutoSize = true;
            this.刷空图按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.刷空图按钮.Location = new System.Drawing.Point(300, 27);
            this.刷空图按钮.Name = "刷空图按钮";
            this.刷空图按钮.Size = new System.Drawing.Size(59, 24);
            this.刷空图按钮.TabIndex = 3;
            this.刷空图按钮.Text = "刷空图";
            this.toolTip1.SetToolTip(this.刷空图按钮, "新建一张由左边宽高和颜色参数设定的位图");
            this.刷空图按钮.UseVisualStyleBackColor = true;
            this.刷空图按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 神经网络panel
            // 
            this.神经网络panel.Controls.Add(this.Mnist查看按钮);
            this.神经网络panel.Controls.Add(this.读Yolo标签按钮);
            this.神经网络panel.Location = new System.Drawing.Point(0, 131);
            this.神经网络panel.Margin = new System.Windows.Forms.Padding(0);
            this.神经网络panel.Name = "神经网络panel";
            this.神经网络panel.Size = new System.Drawing.Size(1131, 128);
            this.神经网络panel.TabIndex = 2;
            // 
            // Mnist查看按钮
            // 
            this.Mnist查看按钮.Location = new System.Drawing.Point(88, 3);
            this.Mnist查看按钮.Name = "Mnist查看按钮";
            this.Mnist查看按钮.Size = new System.Drawing.Size(72, 23);
            this.Mnist查看按钮.TabIndex = 1;
            this.Mnist查看按钮.Text = "Mnist查看";
            this.toolTip1.SetToolTip(this.Mnist查看按钮, "新建一个Mnist数字查看页,点\'读之\'按钮");
            this.Mnist查看按钮.UseVisualStyleBackColor = true;
            this.Mnist查看按钮.Click += new System.EventHandler(this.神经网络按钮们_Click);
            // 
            // 读Yolo标签按钮
            // 
            this.读Yolo标签按钮.Location = new System.Drawing.Point(3, 3);
            this.读Yolo标签按钮.Name = "读Yolo标签按钮";
            this.读Yolo标签按钮.Size = new System.Drawing.Size(79, 23);
            this.读Yolo标签按钮.TabIndex = 0;
            this.读Yolo标签按钮.Text = "读Yolo标签";
            this.toolTip1.SetToolTip(this.读Yolo标签按钮, "把Yolo标签里的框和类别显示到相应的图片上");
            this.读Yolo标签按钮.UseVisualStyleBackColor = true;
            this.读Yolo标签按钮.Click += new System.EventHandler(this.神经网络按钮们_Click);
            // 
            // 点运算按钮
            // 
            this.点运算按钮.AutoSize = true;
            this.点运算按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.点运算按钮.Location = new System.Drawing.Point(300, 77);
            this.点运算按钮.Name = "点运算按钮";
            this.点运算按钮.Size = new System.Drawing.Size(59, 24);
            this.点运算按钮.TabIndex = 10;
            this.点运算按钮.Text = "点运算";
            this.toolTip1.SetToolTip(this.点运算按钮, "每个点的RGB值乘以W加b");
            this.点运算按钮.UseVisualStyleBackColor = true;
            this.点运算按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 转灰度按钮
            // 
            this.转灰度按钮.AutoSize = true;
            this.转灰度按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.转灰度按钮.Location = new System.Drawing.Point(300, 52);
            this.转灰度按钮.Name = "转灰度按钮";
            this.转灰度按钮.Size = new System.Drawing.Size(59, 24);
            this.转灰度按钮.TabIndex = 11;
            this.转灰度按钮.Text = "转灰度";
            this.toolTip1.SetToolTip(this.转灰度按钮, "RGB按照右边比值转为灰度");
            this.转灰度按钮.UseVisualStyleBackColor = true;
            this.转灰度按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 变透明按钮
            // 
            this.变透明按钮.AutoSize = true;
            this.变透明按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.变透明按钮.Location = new System.Drawing.Point(364, 102);
            this.变透明按钮.Name = "变透明按钮";
            this.变透明按钮.Size = new System.Drawing.Size(59, 24);
            this.变透明按钮.TabIndex = 12;
            this.变透明按钮.Text = "变透明";
            this.toolTip1.SetToolTip(this.变透明按钮, "把上面设定的RGB颜色变为透明. 双击图像上的点可取色");
            this.变透明按钮.UseVisualStyleBackColor = true;
            this.变透明按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 变RAW按钮
            // 
            this.变RAW按钮.AutoSize = true;
            this.变RAW按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.变RAW按钮.Location = new System.Drawing.Point(299, 102);
            this.变RAW按钮.Name = "变RAW按钮";
            this.变RAW按钮.Size = new System.Drawing.Size(60, 24);
            this.变RAW按钮.TabIndex = 13;
            this.变RAW按钮.Text = "变RAW";
            this.toolTip1.SetToolTip(this.变RAW按钮, "把RGB图转回没插值前的Raw格式");
            this.变RAW按钮.UseVisualStyleBackColor = true;
            this.变RAW按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // RGB增益按钮
            // 
            this.RGB增益按钮.AutoSize = true;
            this.RGB增益按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RGB增益按钮.Location = new System.Drawing.Point(427, 102);
            this.RGB增益按钮.Name = "RGB增益按钮";
            this.RGB增益按钮.Size = new System.Drawing.Size(45, 24);
            this.RGB增益按钮.TabIndex = 14;
            this.RGB增益按钮.Text = "增益";
            this.toolTip1.SetToolTip(this.RGB增益按钮, "每个点的RGB值分别乘以上面的比例值");
            this.RGB增益按钮.UseVisualStyleBackColor = true;
            this.RGB增益按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 二图相减按钮
            // 
            this.二图相减按钮.AutoSize = true;
            this.二图相减按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.二图相减按钮.Location = new System.Drawing.Point(477, 102);
            this.二图相减按钮.Name = "二图相减按钮";
            this.二图相减按钮.Size = new System.Drawing.Size(73, 24);
            this.二图相减按钮.TabIndex = 15;
            this.二图相减按钮.Text = "二图相减";
            this.toolTip1.SetToolTip(this.二图相减按钮, "把长宽相同的两幅图逐像素相减");
            this.二图相减按钮.UseVisualStyleBackColor = true;
            this.二图相减按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 画直方图按钮
            // 
            this.画直方图按钮.AutoSize = true;
            this.画直方图按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.画直方图按钮.ForeColor = System.Drawing.SystemColors.ControlText;
            this.画直方图按钮.Location = new System.Drawing.Point(226, 2);
            this.画直方图按钮.Name = "画直方图按钮";
            this.画直方图按钮.Size = new System.Drawing.Size(59, 24);
            this.画直方图按钮.TabIndex = 16;
            this.画直方图按钮.Text = "直方图";
            this.toolTip1.SetToolTip(this.画直方图按钮, "画一幅图片的RGB, HSL直方图. HS直方图中颜色深代表点数多.");
            this.画直方图按钮.UseVisualStyleBackColor = true;
            this.画直方图按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 直方图均衡化按钮
            // 
            this.直方图均衡化按钮.AutoSize = true;
            this.直方图均衡化按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.直方图均衡化按钮.Location = new System.Drawing.Point(226, 27);
            this.直方图均衡化按钮.Name = "直方图均衡化按钮";
            this.直方图均衡化按钮.Size = new System.Drawing.Size(59, 24);
            this.直方图均衡化按钮.TabIndex = 17;
            this.直方图均衡化按钮.Text = "均衡化";
            this.toolTip1.SetToolTip(this.直方图均衡化按钮, "直方图均衡化处理");
            this.直方图均衡化按钮.UseVisualStyleBackColor = true;
            this.直方图均衡化按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // Canny按钮
            // 
            this.Canny按钮.AutoSize = true;
            this.Canny按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Canny按钮.Location = new System.Drawing.Point(226, 77);
            this.Canny按钮.Name = "Canny按钮";
            this.Canny按钮.Size = new System.Drawing.Size(59, 24);
            this.Canny按钮.TabIndex = 23;
            this.Canny按钮.Text = "Canny";
            this.toolTip1.SetToolTip(this.Canny按钮, "Canny边缘检测");
            this.Canny按钮.UseVisualStyleBackColor = true;
            this.Canny按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // Sobel按钮
            // 
            this.Sobel按钮.AutoSize = true;
            this.Sobel按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Sobel按钮.Location = new System.Drawing.Point(226, 52);
            this.Sobel按钮.Name = "Sobel按钮";
            this.Sobel按钮.Size = new System.Drawing.Size(59, 24);
            this.Sobel按钮.TabIndex = 22;
            this.Sobel按钮.Text = "Sobel";
            this.toolTip1.SetToolTip(this.Sobel按钮, "Sobel边缘检测算子");
            this.Sobel按钮.UseVisualStyleBackColor = true;
            this.Sobel按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 标背景按钮
            // 
            this.标背景按钮.AutoSize = true;
            this.标背景按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.标背景按钮.Location = new System.Drawing.Point(3, 2);
            this.标背景按钮.Name = "标背景按钮";
            this.标背景按钮.Size = new System.Drawing.Size(59, 24);
            this.标背景按钮.TabIndex = 20;
            this.标背景按钮.Text = "标背景";
            this.toolTip1.SetToolTip(this.标背景按钮, "把HSL值在右边上下限之内的点颜色改为左边设置的RGB值");
            this.标背景按钮.UseVisualStyleBackColor = true;
            this.标背景按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 二值化按钮
            // 
            this.二值化按钮.AutoSize = true;
            this.二值化按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.二值化按钮.Location = new System.Drawing.Point(3, 27);
            this.二值化按钮.Name = "二值化按钮";
            this.二值化按钮.Size = new System.Drawing.Size(59, 24);
            this.二值化按钮.TabIndex = 21;
            this.二值化按钮.Text = "二值化";
            this.toolTip1.SetToolTip(this.二值化按钮, "二值化图像, 右边HSL范围内的点变为黑色背景");
            this.二值化按钮.UseVisualStyleBackColor = true;
            this.二值化按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 递归连通按钮
            // 
            this.递归连通按钮.AutoSize = true;
            this.递归连通按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.递归连通按钮.Location = new System.Drawing.Point(3, 103);
            this.递归连通按钮.Name = "递归连通按钮";
            this.递归连通按钮.Size = new System.Drawing.Size(73, 24);
            this.递归连通按钮.TabIndex = 24;
            this.递归连通按钮.Text = "递归连通";
            this.toolTip1.SetToolTip(this.递归连通按钮, "二值图像递归法连通域标记, 点多会爆栈!");
            this.递归连通按钮.UseVisualStyleBackColor = true;
            this.递归连通按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 是否显示过程
            // 
            this.是否显示过程.AutoSize = true;
            this.是否显示过程.Location = new System.Drawing.Point(82, 106);
            this.是否显示过程.Name = "是否显示过程";
            this.是否显示过程.Size = new System.Drawing.Size(75, 21);
            this.是否显示过程.TabIndex = 25;
            this.是否显示过程.Text = "显示过程";
            this.toolTip1.SetToolTip(this.是否显示过程, "勾选显示连通域标记相邻点的过程");
            this.是否显示过程.UseVisualStyleBackColor = true;
            // 
            // 阈值胀蚀按钮
            // 
            this.阈值胀蚀按钮.AutoSize = true;
            this.阈值胀蚀按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.阈值胀蚀按钮.Location = new System.Drawing.Point(3, 77);
            this.阈值胀蚀按钮.Name = "阈值胀蚀按钮";
            this.阈值胀蚀按钮.Size = new System.Drawing.Size(59, 24);
            this.阈值胀蚀按钮.TabIndex = 27;
            this.阈值胀蚀按钮.Text = "阈胀蚀";
            this.toolTip1.SetToolTip(this.阈值胀蚀按钮, "可调阈值的膨胀腐蚀");
            this.阈值胀蚀按钮.UseVisualStyleBackColor = true;
            this.阈值胀蚀按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 取边缘按钮
            // 
            this.取边缘按钮.AutoSize = true;
            this.取边缘按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.取边缘按钮.Location = new System.Drawing.Point(3, 52);
            this.取边缘按钮.Name = "取边缘按钮";
            this.取边缘按钮.Size = new System.Drawing.Size(59, 24);
            this.取边缘按钮.TabIndex = 28;
            this.取边缘按钮.Text = "取边缘";
            this.toolTip1.SetToolTip(this.取边缘按钮, "仅留下二值图像的边缘部分");
            this.取边缘按钮.UseVisualStyleBackColor = true;
            this.取边缘按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // H使能
            // 
            this.H使能.AutoSize = true;
            this.H使能.Checked = true;
            this.H使能.CheckState = System.Windows.Forms.CheckState.Checked;
            this.H使能.Location = new System.Drawing.Point(104, 53);
            this.H使能.Name = "H使能";
            this.H使能.Size = new System.Drawing.Size(36, 21);
            this.H使能.TabIndex = 29;
            this.H使能.Text = "H";
            this.toolTip1.SetToolTip(this.H使能, "选中代表这组阈值起作用");
            this.H使能.UseVisualStyleBackColor = true;
            this.H使能.CheckedChanged += new System.EventHandler(this.H使能_CheckedChanged);
            // 
            // S使能
            // 
            this.S使能.AutoSize = true;
            this.S使能.Location = new System.Drawing.Point(142, 53);
            this.S使能.Name = "S使能";
            this.S使能.Size = new System.Drawing.Size(34, 21);
            this.S使能.TabIndex = 30;
            this.S使能.Text = "S";
            this.toolTip1.SetToolTip(this.S使能, "选中代表这组阈值起作用");
            this.S使能.UseVisualStyleBackColor = true;
            this.S使能.CheckedChanged += new System.EventHandler(this.H使能_CheckedChanged);
            // 
            // L使能
            // 
            this.L使能.AutoSize = true;
            this.L使能.Location = new System.Drawing.Point(180, 53);
            this.L使能.Name = "L使能";
            this.L使能.Size = new System.Drawing.Size(33, 21);
            this.L使能.TabIndex = 31;
            this.L使能.Text = "L";
            this.toolTip1.SetToolTip(this.L使能, "选中代表这组阈值起作用");
            this.L使能.UseVisualStyleBackColor = true;
            this.L使能.CheckedChanged += new System.EventHandler(this.H使能_CheckedChanged);
            // 
            // 方波展开按钮
            // 
            this.方波展开按钮.AutoSize = true;
            this.方波展开按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.方波展开按钮.Location = new System.Drawing.Point(563, 2);
            this.方波展开按钮.Name = "方波展开按钮";
            this.方波展开按钮.Size = new System.Drawing.Size(45, 24);
            this.方波展开按钮.TabIndex = 32;
            this.方波展开按钮.Text = "方波";
            this.toolTip1.SetToolTip(this.方波展开按钮, "新建一个方波傅里叶展开页");
            this.方波展开按钮.UseVisualStyleBackColor = true;
            this.方波展开按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 三角波展开按钮
            // 
            this.三角波展开按钮.AutoSize = true;
            this.三角波展开按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.三角波展开按钮.Location = new System.Drawing.Point(614, 2);
            this.三角波展开按钮.Name = "三角波展开按钮";
            this.三角波展开按钮.Size = new System.Drawing.Size(59, 24);
            this.三角波展开按钮.TabIndex = 33;
            this.三角波展开按钮.Text = "三角波";
            this.toolTip1.SetToolTip(this.三角波展开按钮, "三角波傅里叶展开");
            this.三角波展开按钮.UseVisualStyleBackColor = true;
            this.三角波展开按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // 金拱门展开按钮
            // 
            this.金拱门展开按钮.AutoSize = true;
            this.金拱门展开按钮.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.金拱门展开按钮.Location = new System.Drawing.Point(679, 2);
            this.金拱门展开按钮.Name = "金拱门展开按钮";
            this.金拱门展开按钮.Size = new System.Drawing.Size(59, 24);
            this.金拱门展开按钮.TabIndex = 34;
            this.金拱门展开按钮.Text = "金拱门";
            this.toolTip1.SetToolTip(this.金拱门展开按钮, "新建傅里叶展开页");
            this.金拱门展开按钮.UseVisualStyleBackColor = true;
            this.金拱门展开按钮.Click += new System.EventHandler(this.图像处理按钮们_Click);
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.Controls.Add(this.金拱门展开按钮);
            this.panel1.Controls.Add(this.三角波展开按钮);
            this.panel1.Controls.Add(this.方波展开按钮);
            this.panel1.Controls.Add(this.L使能);
            this.panel1.Controls.Add(this.S使能);
            this.panel1.Controls.Add(this.H使能);
            this.panel1.Controls.Add(this.取边缘按钮);
            this.panel1.Controls.Add(this.阈值胀蚀按钮);
            this.panel1.Controls.Add(this.toolStrip3);
            this.panel1.Controls.Add(this.是否显示过程);
            this.panel1.Controls.Add(this.递归连通按钮);
            this.panel1.Controls.Add(this.Canny按钮);
            this.panel1.Controls.Add(this.Sobel按钮);
            this.panel1.Controls.Add(this.二值化按钮);
            this.panel1.Controls.Add(this.标背景按钮);
            this.panel1.Controls.Add(this.toolStrip2);
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Controls.Add(this.直方图均衡化按钮);
            this.panel1.Controls.Add(this.画直方图按钮);
            this.panel1.Controls.Add(this.二图相减按钮);
            this.panel1.Controls.Add(this.RGB增益按钮);
            this.panel1.Controls.Add(this.变RAW按钮);
            this.panel1.Controls.Add(this.变透明按钮);
            this.panel1.Controls.Add(this.转灰度按钮);
            this.panel1.Controls.Add(this.点运算按钮);
            this.panel1.Controls.Add(this.刷空图按钮);
            this.panel1.Controls.Add(this.Wb选值);
            this.panel1.Controls.Add(this.宽高参数);
            this.panel1.Controls.Add(this.RGB参数);
            this.panel1.Controls.Add(this.点运算参数);
            this.panel1.Controls.Add(this.增益参数);
            this.panel1.Controls.Add(this.随机刷按钮);
            this.panel1.Location = new System.Drawing.Point(70, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1219, 128);
            this.panel1.TabIndex = 10;
            // 
            // toolStrip3
            // 
            this.toolStrip3.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel3,
            this.算子直径,
            this.toolStripLabel7,
            this.胀蚀阈值});
            this.toolStrip3.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip3.Location = new System.Drawing.Point(65, 77);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(145, 23);
            this.toolStrip3.TabIndex = 26;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(37, 20);
            this.toolStripLabel3.Text = "直径";
            this.toolStripLabel3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.toolStripLabel3.ToolTipText = "二值算子直径";
            // 
            // 算子直径
            // 
            this.算子直径.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.算子直径.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.算子直径.ForeColor = System.Drawing.SystemColors.ControlText;
            this.算子直径.MaxLength = 2;
            this.算子直径.Name = "算子直径";
            this.算子直径.Size = new System.Drawing.Size(24, 22);
            this.算子直径.Text = "3";
            this.算子直径.ToolTipText = "算子直径. 需为奇数, 最小为3";
            this.算子直径.Validated += new System.EventHandler(this.算子直径_Validated);
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(37, 20);
            this.toolStripLabel7.Text = "阈值";
            this.toolStripLabel7.ToolTipText = "阈值为1时为膨胀效果, 阈值为直径平方时为腐蚀效果. ";
            // 
            // 胀蚀阈值
            // 
            this.胀蚀阈值.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.胀蚀阈值.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.胀蚀阈值.ForeColor = System.Drawing.SystemColors.ControlText;
            this.胀蚀阈值.MaxLength = 4;
            this.胀蚀阈值.Name = "胀蚀阈值";
            this.胀蚀阈值.Size = new System.Drawing.Size(42, 22);
            this.胀蚀阈值.Text = "1";
            this.胀蚀阈值.ToolTipText = "阈值最大值为直径的平方, 最小为1";
            this.胀蚀阈值.Validated += new System.EventHandler(this.胀蚀阈值_TextChanged);
            this.胀蚀阈值.TextChanged += new System.EventHandler(this.胀蚀阈值_TextChanged);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.下限标签,
            this.H下,
            this.toolStripSeparator7,
            this.S下,
            this.toolStripSeparator8,
            this.L下});
            this.toolStrip2.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip2.Location = new System.Drawing.Point(65, 28);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(146, 23);
            this.toolStrip2.TabIndex = 19;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // 下限标签
            // 
            this.下限标签.Name = "下限标签";
            this.下限标签.Size = new System.Drawing.Size(37, 20);
            this.下限标签.Text = "下限";
            this.下限标签.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.下限标签.ToolTipText = "HSL值下限. 用于标记背景和二值化";
            // 
            // H下
            // 
            this.H下.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.H下.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.H下.ForeColor = System.Drawing.Color.Purple;
            this.H下.MaxLength = 3;
            this.H下.Name = "H下";
            this.H下.Size = new System.Drawing.Size(30, 22);
            this.H下.Text = "140";
            this.H下.ToolTipText = "H色调下限";
            this.H下.TextChanged += new System.EventHandler(this.HSL上下限_TextChanged);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 23);
            // 
            // S下
            // 
            this.S下.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.S下.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.S下.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.S下.MaxLength = 3;
            this.S下.Name = "S下";
            this.S下.Size = new System.Drawing.Size(30, 22);
            this.S下.Text = "0";
            this.S下.ToolTipText = "S饱和度下限";
            this.S下.TextChanged += new System.EventHandler(this.HSL上下限_TextChanged);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 23);
            // 
            // L下
            // 
            this.L下.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.L下.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L下.ForeColor = System.Drawing.SystemColors.ControlText;
            this.L下.MaxLength = 3;
            this.L下.Name = "L下";
            this.L下.Size = new System.Drawing.Size(30, 22);
            this.L下.Text = "0";
            this.L下.ToolTipText = "L亮度值下限";
            this.L下.TextChanged += new System.EventHandler(this.HSL上下限_TextChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.上限标签,
            this.H上,
            this.toolStripSeparator5,
            this.S上,
            this.toolStripSeparator6,
            this.L上});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(65, 2);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(146, 23);
            this.toolStrip1.TabIndex = 18;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // 上限标签
            // 
            this.上限标签.ForeColor = System.Drawing.SystemColors.ControlText;
            this.上限标签.Name = "上限标签";
            this.上限标签.Size = new System.Drawing.Size(37, 20);
            this.上限标签.Text = "上限";
            this.上限标签.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.上限标签.ToolTipText = "HSL值上限. 用于标记背景和二值化";
            // 
            // H上
            // 
            this.H上.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.H上.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.H上.ForeColor = System.Drawing.Color.Purple;
            this.H上.MaxLength = 3;
            this.H上.Name = "H上";
            this.H上.Size = new System.Drawing.Size(30, 22);
            this.H上.Text = "160";
            this.H上.ToolTipText = "H色调上限";
            this.H上.TextChanged += new System.EventHandler(this.HSL上下限_TextChanged);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 23);
            // 
            // S上
            // 
            this.S上.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.S上.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.S上.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.S上.MaxLength = 3;
            this.S上.Name = "S上";
            this.S上.Size = new System.Drawing.Size(30, 22);
            this.S上.Text = "240";
            this.S上.ToolTipText = "S饱和度上限";
            this.S上.TextChanged += new System.EventHandler(this.HSL上下限_TextChanged);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 23);
            // 
            // L上
            // 
            this.L上.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.L上.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.L上.ForeColor = System.Drawing.SystemColors.ControlText;
            this.L上.MaxLength = 3;
            this.L上.Name = "L上";
            this.L上.Size = new System.Drawing.Size(30, 22);
            this.L上.Text = "240";
            this.L上.ToolTipText = "L亮度值上限";
            this.L上.TextChanged += new System.EventHandler(this.HSL上下限_TextChanged);
            // 
            // 功能标签页
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.切换工具栏);
            this.Controls.Add(this.神经网络panel);
            this.Name = "功能标签页";
            this.Size = new System.Drawing.Size(1289, 512);
            this.toolTip1.SetToolTip(this, " ");
            this.切换工具栏.ResumeLayout(false);
            this.切换工具栏.PerformLayout();
            this.点运算参数.ResumeLayout(false);
            this.点运算参数.PerformLayout();
            this.增益参数.ResumeLayout(false);
            this.增益参数.PerformLayout();
            this.RGB参数.ResumeLayout(false);
            this.RGB参数.PerformLayout();
            this.宽高参数.ResumeLayout(false);
            this.宽高参数.PerformLayout();
            this.神经网络panel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ToolStrip 切换工具栏;
        private ToolStripButton 图像处理按钮;
        private ToolStripButton 神经网络按钮;
        private Button 刷空图按钮;
        private Panel 神经网络panel;
        private Button 读Yolo标签按钮;
        private ToolStrip 宽高参数;
        private ToolStripLabel toolStripLabel1;
        private ToolStripTextBox 图宽;
        private ToolStripLabel toolStripLabel2;
        private ToolStripTextBox 图高;
        private ToolStripSplitButton 位宽选择;
        private ToolStripMenuItem toolStripMenuItem2;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolTip toolTip1;
        private ToolStrip RGB参数;
        private ToolStripLabel RGB标签;
        private ToolStripTextBox R值;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripTextBox G值;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripTextBox B值;
        private ToolStripButton 选色按钮;
        private ToolStrip 增益参数;
        private ToolStripLabel toolStripLabel4;
        private ToolStripTextBox R比例;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripTextBox G比例;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripTextBox B比例;
        private Button 随机刷按钮;
        private ToolStrip 点运算参数;
        private ToolStripLabel toolStripLabel5;
        private ToolStripTextBox W值;
        private ToolStripLabel toolStripLabel6;
        private ToolStripTextBox Bias值;
        private ComboBox Wb选值;
        private Panel panel1;
        private Button 转灰度按钮;
        private Button 点运算按钮;
        private Button 变透明按钮;
        private Button RGB增益按钮;
        private Button 变RAW按钮;
        private Button 二图相减按钮;
        private Button 画直方图按钮;
        private Button 直方图均衡化按钮;
        private Button Canny按钮;
        private Button Sobel按钮;
        private Button 二值化按钮;
        private Button 标背景按钮;
        private ToolStrip toolStrip2;
        private ToolStripLabel 下限标签;
        private ToolStripTextBox H下;
        private ToolStripSeparator toolStripSeparator7;
        private ToolStripTextBox S下;
        private ToolStripSeparator toolStripSeparator8;
        private ToolStripTextBox L下;
        private ToolStrip toolStrip1;
        private ToolStripLabel 上限标签;
        private ToolStripTextBox H上;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripTextBox S上;
        private ToolStripSeparator toolStripSeparator6;
        private ToolStripTextBox L上;
        private Button 递归连通按钮;
        private CheckBox 是否显示过程;
        private ToolStrip toolStrip3;
        private ToolStripLabel toolStripLabel3;
        private ToolStripTextBox 算子直径;
        private ToolStripTextBox 胀蚀阈值;
        private ToolStripLabel toolStripLabel7;
        private Button 阈值胀蚀按钮;
        private Button 取边缘按钮;
        private CheckBox L使能;
        private CheckBox S使能;
        private CheckBox H使能;
        private Button 金拱门展开按钮;
        private Button 三角波展开按钮;
        private Button 方波展开按钮;
        private Button Mnist查看按钮;
    }
}
